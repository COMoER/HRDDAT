## Jidi environment wrapper

Here lies the environment wrapper for the running scenario which is also the env-wrapper we use to evaluate your submission on Jidi platform.

